
#  prefix-set-service 

###  1. Introduction:

This package will configure prefix-sets to be later applied to IOS-XR based BGP peering configurations.

##### Following configurations are supported as part of this service

* prefix-set on single or multiple IOS-XR devices.
	
### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# services prefix-set-service prefix-set-ipv4 user-defined-prefix-set-name prefix-set-v4 device iosxr-07 prefix-set-match-specification ip-version ipv4 prefix-set-match-specification 1 address 10.0.1.1 mask-length 24 exact-prefix-len-equal-to 28
admin@ncs(config-prefix-set-match-specification-1)# top
admin@ncs(config)# services prefix-set-service prefix-set-ipv4 user-defined-prefix-set-name prefix-set-v4 device iosxr-07 prefix-set-match-specification ip-version ipv4 prefix-set-match-specification 2 address 10.0.7.2 mask-length 32 prefix-len-greater-than-equal-to 16 prefix-len-less-than-equal-to 24
admin@ncs(config-prefix-set-match-specification-2)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-07
        data prefix-set prefix-set-v4
              10.0.1.1/24 eq 28
              10.0.7.2/32 ge 16 le 24
              end-set
             !
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ prefix-set-service Demo ](https://cisco.box.com/s/tfapkcrdwotu8adu5zvjo7netp9w84x8)

  Password : **CEC Credentials**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
