# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service


# ------------------------
# SERVICE CALLBACK EXAMPLE
# ------------------------
class PrefixSetServiceCallback(Service):

    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.debug('Service create(service=', service._path, ')')
        
        #Declare local variables
        match_specification_cont = None
        prefix_set_name = None
        vars = ncs.template.Variables()
        template = ncs.template.Template(service)

        # Parse the service inputs
        prefix_set_name_choice = service.prefix_set_name_choice
        
        if prefix_set_name_choice == 'user-defined-prefix-set-name':
            prefix_set_name = service.user_defined_prefix_set_name
        elif prefix_set_name_choice == 'pre-defined-prefix-set-name':
            #User Chose to deploy Pre-defined prefix set
            prefix_set_name = service.pre_defined_prefix_set_name
            pre_defined_prefix_set = root.pre_defined_rpl_configs.prefix_set[prefix_set_name].set
            for set in pre_defined_prefix_set:
                prefix_set_value = set.value
                vars.add('PREFIX_SET_NAME', prefix_set_name)
                vars.add('PREFIX_SET_VALUE', prefix_set_value)
                template.apply('prefix-set-service-template', vars)
            
        # User defined prefix-set match specifications
        ip_version = str(service.prefix_set_match_specification.ip_version)
        if ip_version != None:
            if ip_version == 'ipv4':
                match_specification_cont = service.prefix_set_match_specification.ipv4
            elif ip_version == 'ipv6':
                match_specification_cont = service.prefix_set_match_specification.ipv6
         
        if match_specification_cont != None:   
            match_specs = match_specification_cont.prefix_set_match_specification
            for match_spec in match_specs:
                prefix_set_value = match_spec.address
                min_match_len = match_spec.matching_prefix_range.prefix_len_greater_than_equal_to
                mask_len = match_spec.mask_length
    	        max_match_len = match_spec.matching_prefix_range.prefix_len_less_than_equal_to
                exact_prefix_len = match_spec.exact_prefix_len_equal_to
    
                if mask_len != None and mask_len !='':
                    prefix_set_value += '/' + str(mask_len)
                if min_match_len != None and min_match_len !='':
                    prefix_set_value = prefix_set_value + ' ge ' + str(min_match_len) 
                if max_match_len != None and max_match_len !='':
                    prefix_set_value = prefix_set_value + ' le ' + str(max_match_len)
                if exact_prefix_len != None and exact_prefix_len !='':
                    prefix_set_value = prefix_set_value + ' eq ' + str(exact_prefix_len)
                
                vars.add('PREFIX_SET_NAME', prefix_set_name)
                vars.add('PREFIX_SET_VALUE', prefix_set_value)
                template.apply('prefix-set-service-template', vars)

# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class PrefixSetService(ncs.application.Application):
    def setup(self):
        self.log.debug('PrefixSetService RUNNING')

        # Register the service as specified in the prefix-set-service.yang
        self.register_service('prefix-set-service-servicepoint', PrefixSetServiceCallback)

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.debug('PrefixSetService FINISHED')
