# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service


# ------------------------
# ROUTE-POLICY SERVICE CALLBACK
# ------------------------
class RoutePolicyServiceCallback(Service):

    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.debug('Service create(service=', service._path, ')')

        #Initialize local variables        
        vars = ncs.template.Variables()
        template = ncs.template.Template(service)
        route_policy_name = None
        route_policy_value = ''
        
        #Parse the service inputs
        devices = service.device
        route_policy_name_choice = service.route_policy_name_choice
        if route_policy_name_choice == 'user-defined-route-policy':
            route_policy_name = service.user_defined_route_policy.user_defined_route_policy_name
            parameter_list = service.user_defined_route_policy.parameter_list.as_list()
            if len(parameter_list)>0:
                route_policy_name = route_policy_name + '('
                for parameter in parameter_list:
                    if parameter_list.index(parameter) == 0:
                        route_policy_name = route_policy_name + parameter
                    else:
                        route_policy_name = route_policy_name + ', ' + parameter
                route_policy_name = route_policy_name + ')'
        elif route_policy_name_choice == 'pre-defined-route-policy':
            route_policy_name = service.pre_defined_route_policy
            route_policy_value = root.pre_defined_rpl_configs.route_policy[route_policy_name].value
            
            
        # Parse route-policy statements to form the algorithm
        route_policy_statements = service.route_policy_statements
        for route_policy in route_policy_statements:
            policy_statement = route_policy.policy_statement_type
            route_policy_value = self.generate_rpl_alg(route_policy, route_policy_value, policy_statement)
                    
            if policy_statement == 'begin-if-statement':
                conditions = route_policy.route_policy_conditions_block
                for condition in conditions:
                    if_else_condition_type = str(condition.if_else_condition_type)
                    if if_else_condition_type == 'if' or if_else_condition_type == 'else-if':
                        comparing_attribute = str(condition.comparing_attribute)
                        comparator = str(condition.comparator)
                        comparing_value = str(condition.comparing_value)
                        route_policy_value = route_policy_value + '  ' + if_else_condition_type + ' ' + comparing_attribute + ' ' + comparator + ' ' + comparing_value + ' then \r\n'
                    if if_else_condition_type == 'if' or if_else_condition_type == 'else-if' or if_else_condition_type == 'else':
                        policy_condition_statements = condition.route_policy_condition_statements
                        for policy_cond_stmt in policy_condition_statements:
                            policy_cond_stmt_type = policy_cond_stmt.policy_statement_type
                            route_policy_value = self.generate_rpl_alg(policy_cond_stmt, route_policy_value + '  ', policy_cond_stmt_type)
                route_policy_value = route_policy_value + '  end-if\r\n'    

        vars.add('ROUTE_POLICY_NAME', route_policy_name)
        vars.add('ROUTE_POLICY_VALUE', route_policy_value)
        template.apply('routing-policy-service-template', vars)


    # Function definition for generating route-policy alg
    def generate_rpl_alg(self, route_policy, route_policy_value, policy_statement):
        if policy_statement == 'set-origin':
            route_policy_value = route_policy_value + '  set origin ' + str(route_policy.origin) + '\r\n'
        elif policy_statement == 'set-median':
            route_policy_value = route_policy_value + '  set med ' + str(route_policy.median) + '\r\n'
        elif policy_statement == 'set-local-preference':
            route_policy_value = route_policy_value + '  set local-preference ' + str(route_policy.local_preference) + '\r\n'
        elif policy_statement == 'set-community':
            route_policy_value = route_policy_value + '  set community '
            community_value_choice = route_policy.inline_community_set.community_value_choice
            if community_value_choice == 'standard-community-value':
                std_community_val = str(route_policy.inline_community_set.standard_community_value)
                route_policy_value = route_policy_value + std_community_val.split("  ")[0]
            elif community_value_choice == 'custom-community-value':
                route_policy_value = route_policy_value + ' (' + str(route_policy.inline_community_set.custom_community_value.lower_community_value) + ':' + str(route_policy.inline_community_set.custom_community_route_policy_value.upper_community_value) + ')'
            
            if route_policy.inline_community_set.is_additive:
                route_policy_value = route_policy_value + ' additive'
                
            route_policy_value = route_policy_value + '\r\n'
        elif policy_statement == 'reference-route-policy':
            route_policy_value = route_policy_value + '  apply ' + route_policy.reference_route_policy + '\r\n'
        elif policy_statement == 'set-policy-action':
            route_policy_value = route_policy_value + '  ' + str(route_policy.route_policy_action) + '\r\n'
        elif policy_statement == 'set-policy-variables':
            policy_attributes = route_policy.route_policy_variables
            for attribute in policy_attributes:
                attr_name = attribute.variable_name
                attr_val = attribute.variable_value
                
                route_policy_value = route_policy_value + '  var ' + attr_name + ' ' + attr_val + '\r\n'
                
        return route_policy_value

# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class RoutePolicyService(ncs.application.Application):

    def setup(self):
        self.log.debug('RoutePolicyService RUNNING')

        #Register route-policy service callback with the servicepoint as configured in the route-policy yang model.
        self.register_service('route-policy-service-servicepoint', RoutePolicyServiceCallback)

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.debug('RoutePolicyService FINISHED')
