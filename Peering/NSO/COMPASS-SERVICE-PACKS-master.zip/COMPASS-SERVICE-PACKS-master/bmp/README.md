
#  bmp


###  1. Introduction:

BMP stands for BGP monitoring protocol. The service enables BMP on a per-peer basis to send BGP prefix change events and peer statistics to a BMP monitoring station. 


##### Following configurations are supported as part of this service

* enable or disable bmp server configuration on IOS-XR devices. 

### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# bmp iosxr-09 bmp-server 1 host 12.0.0.1 port 100 vrf NSO-vrf stats-reporting-interval 800 update-source-interface HundredGigE interface-id 0/0/0/1
admin@ncs(config-bmp-server-1)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-09
        data bmp server 1
              host 12.0.0.1 port 100
              vrf                    NSO-vrf
              update-source HundredGigE0/0/0/1
              stats-reporting-period 800
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#


```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.5](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.5.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ BMP Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=9dc3df5b4682488eb39a68c5925fc7a1)

  Password : **DbJ4RVKJ**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
