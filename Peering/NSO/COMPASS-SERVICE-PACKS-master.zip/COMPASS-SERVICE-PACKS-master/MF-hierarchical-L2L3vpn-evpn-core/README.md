
#    MF-hierarchical-L2L3vpn-evpn-core

###  1. Introduction:

This package will configure below 2 types of services
* Hierarchical H-L3VPN with EVPN Core and Anycast Static PW in the Access without IRB Interface (Multipoint service)
* Hierarchical H-L3VPN with EVPN Core and Anycast Static PW in the Access Terminating with IRB Interface (Multipoint service)

##### Following configurations are supported as part of this service

*   l2vpn,interface ( Access PE XR device)
*   interface ( Access PE XE device)
*   interface,l2vpn,evpn,vrf,router-vrf (on Multiple Aggregation PE devices)

### 2. Topology:

* **Hierarchical H-L3VPN with EVPN Core and Anycast Static PW in the Access without IRB Interface (Multipoint service) :**

This package will configure a L2VPN-EVPN service with anycast with no IRB interface

##### [Access Node] —-— (static PW) —-—— [Agg1 & Agg2] ———— (evpn) -—— [Remote Agg/access network]

* **Hierarchical H-L3VPN with EVPN Core and Anycast Static PW in the Access Terminating with IRB Interface (Multipoint service) :**

This package will configure a Hierarchical L2/L3VPN-EVPN service with anycast when terminating on IRB interface.
As part of the service,an EVPN VPWS PW Static-Pseudo wire will be configured between Access and Aggregation and L3 VPN service will be configured between local and remote Aggregation devices.

##### [Access Node] —— (static PW) ———- (irb) [Agg1 & Agg2] ———— (l3vpn with evpn core) ——-- [Remote Agg/access network]

Access Router **:**
NCS5xxx/NCS5xx series router running Cisco's IOS XR software.

Aggregation Router **:**
Cisco ASR9000 series router running IOS XR software.


### 3.	Configuration Example:

```sh

admin@ncs(config)# services MF-hierarchical-L2L3vpn-evpn-core l3vpn-pw-03 pw-id 8001 access-pe-site access-pe iosxr-06 xr-int-type HundredGigE int-id 0/0/1/2 intf-encap dot1q vlan-id 20 sub-intf-id 100 pw-class l2l3vpn-nso-pw ip-addr 100.100.10.13 xconnect-group L2L3vpn-NSO p2p-name P2P-NSO
admin@ncs(config-MF-hierarchical-L2L3vpn-evpn-core-l3vpn-pw-03)# top
admin@ncs(config)# services MF-hierarchical-L2L3vpn-evpn-core l3vpn-pw-03 control-word yes aggregation-pe-site aggregation-pe-list iosxr-07
admin@ncs(config-aggregation-pe-list-iosxr-07)# top
admin@ncs(config)# services MF-hierarchical-L2L3vpn-evpn-core l3vpn-pw-03 control-word yes aggregation-pe-site aggregation-pe-list iosxr-08
admin@ncs(config-aggregation-pe-list-iosxr-08)# top
admin@ncs(config)# services MF-hierarchical-L2L3vpn-evpn-core l3vpn-pw-03 control-word yes aggregation-pe-site int-id 1 pw-class Static-L2l3vpn-NSO evi-id 12001 bridge-group Static-VPWS-H-L3VPN-IRB bridge-domain VRF1 mpls-local-label 3003 mpls-remote-label 4003 neighbor-ip 100.0.1.50 ip-addr 12.0.1.3 ip-mask 255.255.255.0 mac-address 12.0.2 esi-value 12.00.00.00.00.00.50.00.01 vrf L3VPN-AnyCast-ODNTE-VRF1 route-target 100:10001 rt-type both
admin@ncs(config-route-target-100:10001)# top
admin@ncs(config)# services MF-hierarchical-L2L3vpn-evpn-core l3vpn-pw-03 control-word yes aggregation-pe-site local-as 100 bgp-parameters route-distinguisher auto
admin@ncs(config-MF-hierarchical-L2L3vpn-evpn-core-l3vpn-pw-03)# top
admin@ncs(config)# services MF-hierarchical-L2L3vpn-evpn-core l3vpn-pw-03 control-word yes aggregation-pe-site local-as 100 bgp-parameters redistribute-connected  
admin@ncs(config-MF-hierarchical-L2L3vpn-evpn-core-l3vpn-pw-03)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-06
        data interface HundredGigE 0/0/1/2.100 l2transport
              encapsulation dot1q 20
              rewrite ingress tag pop 1 symmetric
             exit
             l2vpn
              pw-class l2l3vpn-nso-pw
               encapsulation mpls
                control-word
               exit
              exit
              xconnect group L2L3vpn-NSO
               p2p P2P-NSO
                interface HundredGigE0/0/1/2.100
                neighbor ipv4 100.100.10.13 pw-id 8001
                 mpls static label local 4003 remote 3003
                 pw-class l2l3vpn-nso-pw
                exit
               exit
              exit
             exit
    }
    device {
        name iosxr-07
        data vrf L3VPN-AnyCast-ODNTE-VRF1
              address-family ipv4 unicast
               import route-target
                100:10001
               exit
               export route-target
                100:10001
               exit
              exit
              address-family ipv6 unicast
               import route-target
                100:10001
               exit
               export route-target
                100:10001
               exit
              exit
             exit
             interface BVI 1
              host-routing
              vrf          L3VPN-AnyCast-ODNTE-VRF1
              ipv4 address 12.0.1.3 255.255.255.0
              mac-address  12.0.2
             exit
             evpn
              evi 12001
               advertise-mac
               exit
              exit
              virtual neighbor 100.0.1.50 pw-id 8001
               ethernet-segment
                identifier type 0 12.00.00.00.00.00.50.00.01
               exit
              exit
             exit
             l2vpn
              pw-class Static-L2l3vpn-NSO
               encapsulation mpls
                control-word
               exit
              exit
              bridge group Static-VPWS-H-L3VPN-IRB
               bridge-domain VRF1
                neighbor 100.0.1.50 pw-id 8001
                 pw-class Static-L2l3vpn-NSO
                 mpls static label local 3003 remote 4003
                exit
                routed interface BVI1
                 split-horizon group core
                 !
                evi 12001
                exit
               exit
              exit
             exit
             router bgp 100
              vrf L3VPN-AnyCast-ODNTE-VRF1
               rd auto
               address-family ipv4 unicast
                redistribute connected
               exit
               address-family ipv6 unicast
                redistribute connected
               exit
              exit
             exit
    }
    device {
        name iosxr-08
        data vrf L3VPN-AnyCast-ODNTE-VRF1
              address-family ipv4 unicast
               import route-target
                100:10001
               exit
               export route-target
                100:10001
               exit
              exit
              address-family ipv6 unicast
               import route-target
                100:10001
               exit
               export route-target
                100:10001
               exit
              exit
             exit
             interface BVI 1
              host-routing
              vrf          L3VPN-AnyCast-ODNTE-VRF1
              ipv4 address 12.0.1.3 255.255.255.0
              mac-address  12.0.2
             exit
             evpn
              evi 12001
               advertise-mac
               exit
              exit
              virtual neighbor 100.0.1.50 pw-id 8001
               ethernet-segment
                identifier type 0 12.00.00.00.00.00.50.00.01
               exit
              exit
             exit
             l2vpn
              pw-class Static-L2l3vpn-NSO
               encapsulation mpls
                control-word
               exit
              exit
              bridge group Static-VPWS-H-L3VPN-IRB
               bridge-domain VRF1
                neighbor 100.0.1.50 pw-id 8001
                 pw-class Static-L2l3vpn-NSO
                 mpls static label local 3003 remote 4003
                exit
                routed interface BVI1
                 split-horizon group core
                 !
                evi 12001
                exit
               exit
              exit
             exit
             router bgp 100
              vrf L3VPN-AnyCast-ODNTE-VRF1
               rd auto
               address-family ipv4 unicast
                redistribute connected
               exit
               address-family ipv6 unicast
                redistribute connected
               exit
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-ios     5.9.2](https://earth.tail-f.com:8443/ncs-pkgs/cisco-ios/4.5.5/ncs-4.5.5-cisco-ios-5.9.2.signed.bin)
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

##### Network Device Validated OS version	:
  * XR software version: 6.3.2
  * XE software version: 16.8.1

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [MF-hierarchical-L2L3vpn-evpn-core Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=e4e4386dab20423e9cad7cfbe62fa2c0)

  Password : **TpJrda4M**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
