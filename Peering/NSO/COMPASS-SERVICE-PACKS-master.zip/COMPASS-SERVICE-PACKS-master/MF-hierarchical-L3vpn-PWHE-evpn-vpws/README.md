
#    MF-hierarchical-L3vpn-PWHE-evpn-vpws

###  1. Introduction:

Hierarchical H-L3VPN Service with Access Nodes Terminating into L3VPN via PWHE Interface


##### Following configurations are supported as part of this service

*   interface (on Aggregation PE device and Access PE device)
*   l2vpn (on Aggregation PE device and Access PE device)
*   prefix-set (on Access PE device)
*   generic-interface-list (on Access PE device)
*   router-vrf (on Access PE device)
*   create vrf with address-family and route-targets


### 2. Topology:

##### [Access Router] -—— (EVPN VPWS) ——— (PWHE) [Aggregation Router] ———— (L3vpn) ——- [Remote Aggregation/access network]  

Access Router **:**
NCS5xxx/NCS5xx series router running Cisco's IOS XR software.

Aggregation Router **:**
Cisco ASR9000 series router running IOS XR software.


### 3.	Configuration Example:

```sh

admin@ncs(config)# services MF-hierarchical-L3vpn-PWHE-evpn-vpws L3vpn03 evi-id 80 xconnect-group-name evpn-vpws-l3vpn-PE3-nso p2p-name odn-3-nso aggregation-pe-site aggregation-pe iosxr-01 int-id 40 ip-addr 10.3.1.3 ip-mask 255.255.0.0 generic-interface-list-name PWHE-NSO generic-interface-type Bundle-Ether local-as 100 prefix-set-name ODN-IGP-Prefixes-NSO                                       
Value for 'aggregation-pe-site vrf vrf-name' (<string>): L3VPN-ODNTE-VRF3-NSO
Value for 'aggregation-pe-site evi-target' (<unsignedInt>): 535
Value for 'aggregation-pe-site evi-source' (<unsignedInt>): 435
Value for 'access-pe-site access-pe' [cisco-ios-00,cisco-ios-01,cisco-ios-02,cisco-ios-03,...]: cisco-ios-04
Value for 'access-pe-site xe-int-type' [FortyGigabitEthernet,GigabitEthernet,HundredGigE,TenGigabitEthernet]: GigabitEthernet
Value for 'access-pe-site int-id' (<string>): 0/0/0/1
Value for 'access-pe-site intf-encap' [dot1q,untagged]: dot1q
Value for 'access-pe-site vlan-id' (<int, 1 .. 4000>): 10
Value for 'access-pe-site evpn-instance-id' (<int>): 220
Value for 'access-pe-site service-instance-id' (<int>): 440
admin@ncs(config-MF-hierarchical-L3vpn-PWHE-evpn-vpws-L3vpn03)# top
admin@ncs(config)# services MF-hierarchical-L3vpn-PWHE-evpn-vpws L3vpn03 aggregation-pe-site vrf route-distinguisher auto
admin@ncs(config-MF-hierarchical-L3vpn-PWHE-evpn-vpws-L3vpn03)# top
admin@ncs(config)# services MF-hierarchical-L3vpn-PWHE-evpn-vpws L3vpn03 aggregation-pe-site generic-interface-list 110
admin@ncs(config-generic-interface-list-110)# top
admin@ncs(config)# services MF-hierarchical-L3vpn-PWHE-evpn-vpws L3vpn03 aggregation-pe-site generic-interface-list 111
admin@ncs(config-generic-interface-list-111)# top
admin@ncs(config)# services MF-hierarchical-L3vpn-PWHE-evpn-vpws L3vpn03 aggregation-pe-site generic-interface-list 112
admin@ncs(config-generic-interface-list-112)# top
admin@ncs(config)# commit dry-run outformat native                                                                       
native {
    device {
        name cisco-ios-04
        data interface GigabitEthernet0/0/0/1
              no switchport
              service instance 440 ethernet
               encapsulation dot1q 10
               rewrite ingress tag pop 1 symmetric
              exit
              no shutdown
             exit
             l2vpn evpn instance 220 point-to-point
              vpws context evpn-vpws-l3vpn-PE3-nso
               service target 435 source 535
               member GigabitEthernet0/0/0/1 service-instance 440
              !
             !
    }
    device {
        name iosxr-01
        data vrf L3VPN-ODNTE-VRF3-NSO
             exit
             interface PW-Ether 40
              vrf L3VPN-ODNTE-VRF3-NSO
              ipv4 address 10.3.1.3 255.255.0.0
              attach generic-interface-list PWHE-NSO
             exit
             l2vpn
              xconnect group evpn-vpws-l3vpn-PE3-nso
               p2p odn-3-nso
                interface PW-Ether40
                neighbor evpn evi 80 target 535 source 435
                exit
               exit
              exit
             exit
             prefix-set ODN-IGP-Prefixes-NSO
              10.3.1.3/16
              end-set
             !
             generic-interface-list PWHE-NSO
              interface Bundle-Ether110
              interface Bundle-Ether111
              interface Bundle-Ether112
             exit
             router bgp 100
              vrf L3VPN-ODNTE-VRF3-NSO
               rd auto
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-ios     5.9.2](https://earth.tail-f.com:8443/ncs-pkgs/cisco-ios/4.5.5/ncs-4.5.5-cisco-ios-5.9.2.signed.bin)
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

##### Network Device Validated OS version	:
  * XR software version: 6.3.2
  * XE software version: 16.8.1

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ MF-hierarchical-L3vpn-PWHE-evpn-vpws Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=8c503153561047faba1184e4d2556ea8)

  Password : **kSPP7fVa**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
