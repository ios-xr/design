
#  pfs-global-isis

###  1. Introduction:

This package will configure global IS-IS routing on a single IOS-XR based Peering Fabric Spine (PFS) node.

##### Following configurations are supported as part of this service

* Global ISIS configurations on a single Peering fabric spine node only
	
### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# services pfs-isis iosxr-05 isis-router pf-internal is-type level-1 isis-net 21.890.567.4556.122.789.89 loopback0-v4-prefix-sid 12365 lsp-refresh-interval 100
admin@ncs(config-isis-router-pf-internal)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-05
        data router isis pf-internal
              set-overload-bit on-startup wait-for-bgp
              is-type              level-1
              net 21.890.567.4556.122.789.89
              distribute bgp-ls level 1
              log adjacency changes
              log pdu drops
              lsp-refresh-interval 100
              max-lsp-lifetime     65535
              address-family ipv4 unicast
               metric-style  wide
               mpls traffic-eng level-1-2
               mpls traffic-eng router-id Loopback0
               maximum-paths 32
               segment-routing mpls
              exit
              address-family ipv6 unicast
               metric-style  wide
               maximum-paths 32
              exit
              interface Loopback0
                passive
               address-family ipv4 unicast
                metric 10
                prefix-sid absolute 12365
               exit
               address-family ipv6 unicast
                metric 10
               exit
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#


```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ pfs-global-isis Demo ]()

  Password : ** **

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
