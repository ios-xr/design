
#  pfs-isis-core

###  1. Introduction:

This package will configure IS-IS routing on core facing interfaces on a single IOS-XR based Peering Fabric Spine (PFS) node.

##### Following configurations are supported as part of this service

* one spine node with interfaces that face core side of it. 
	
### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# services pfs-isis-core iosxr-06 isis-routing-process-id pf-internal core-interface Bundle-Ether 100 circuit-type level-2-only bfd-minimum-interval 100 bfd-multiplier 3 bfd-fast-detect-ipv4 bfd-fast-detect-ipv6 hmac-md5-hello-password test ipv4-address-family metric 10 enable-TI-LFA-computation
admin@ncs(config-core-interface-Bundle-Ether/100)# top
admin@ncs(config)# services pfs-isis-core iosxr-06 isis-routing-process-id pf-internal core-interface Bundle-Ether 100 ipv6-address-family metric 10                                                                                          admin@ncs(config-core-interface-Bundle-Ether/100)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-06
        data router isis pf-internal
              interface Bundle-Ether100
               circuit-type   level-2-only
               bfd minimum-interval 100
               bfd multiplier   3
               bfd fast-detect ipv4
               bfd fast-detect ipv6
               point-to-point
               hello-password hmac-md5 test
               address-family ipv4 unicast
                metric 10
                fast-reroute per-prefix ti-lfa
               exit
               address-family ipv6 unicast
                metric 10
               exit
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ pfs-isis-core Demo ]()

  Password : ****

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
