

#  pfl-to-pfs-routing

###  1. Introduction:

This package will configure IP routing (IS-IS & BGP) between IOS-XR based Peering Fabric Leaf (PFL) nodes and Peering Fabric Spine (PFS) nodes.

The service configuration is done for each PFL node and associated PFS node(s). Here is a representative workflow for service creation where one chooses:
	    - PFL node name and associated parameters for global-IS-IS and global BGP 
	    - PFS node(s) and associated parameters for IS-IS routing interface and BGP neighbor on each PFS and PFL nodes. 

##### Following configurations are supported as part of this service

* Global BGP on leaf node
* Global IS-IS routing on leaf node  
* IS-IS routing interface on leaf node
* IS-IS routing interface on upstream Spine node(s)
* BGP neighbor on leaf node
* BGP neighbor on upstream spine node(s).


### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# services pfl-to-pfs-routing iosxr-01 isis-router pf-internal isis-net 49.002.1720.1700.2001.00 is-type level-1 loopback0-v4-prefix-sid 16421 lsp-refresh-interval 3000
admin@ncs(config-isis-router-pf-internal)# top
admin@ncs(config)# services pfl-to-pfs-routing iosxr-01 bgp-router 65000 bgp-router-id 172.17.2.1 session-group-encrypted-password test bgp-neighbor 12.0.0.1 remote-as 123 neighbor-group V4-NSO bgp-ipv4-description NSO-PFL
admin@ncs(config-bgp-neighbor-12.0.0.1)# top
admin@ncs(config)# services pfl-to-pfs-routing iosxr-01 pfs-list iosxr-02 pfs-interface HundregGigE 0/0/1/0 circuit-type level-1 bfd-minimum-interval 100 bfd-multiplier 3 bfd-fast-detect-ipv4 bfd-fast-detect-ipv6 hmac-md5-hello-password test ipv4-address-family metric 10 enable-TI-LFA-computation
admin@ncs(config-pfs-interface-HundregGigE/0/0/1/0)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-01
        data router isis pf-internal
              set-overload-bit on-startup wait-for-bgp
              is-type              level-1
              net 49.002.1720.1700.2001.00
              distribute bgp-ls level 1
              log adjacency changes
              log pdu drops
              lsp-refresh-interval 3000
              max-lsp-lifetime     65535
              address-family ipv4 unicast
               metric-style  wide
               mpls traffic-eng level-1-2
               mpls traffic-eng router-id Loopback0
               maximum-paths 32
               segment-routing mpls
              exit
              address-family ipv6 unicast
               metric-style  wide
               maximum-paths 32
              exit
              interface Loopback0
                passive
               address-family ipv4 unicast
                metric 10
                prefix-sid absolute 16421
               exit
               address-family ipv6 unicast
                metric 10
               exit
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ pfl-to-pfs-routing Demo ]()

  Password : ** **

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
