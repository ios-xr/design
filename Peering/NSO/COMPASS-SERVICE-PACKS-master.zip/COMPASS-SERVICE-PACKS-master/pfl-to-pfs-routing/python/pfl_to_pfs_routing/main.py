# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service


# ------------------------
# SERVICE CALLBACK EXAMPLE
# ------------------------
class ServiceCallbacks(Service):

    # The create() callback is invoked inside NCS FASTMAP and
    # must always exist.
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Service create(service=', service._path, ')')

        vars = ncs.template.Variables()
        template = ncs.template.Template(service)
        template.apply('pfl-global-bgp', vars)
        template.apply('pfl-global-isis-routing', vars)
        
        pfl_device_name = service.pfl_device_name
        pfl_bgp_local_as = service.pfl_global_bgp_routing.local_as
        pfl_bgp_router_id = service.pfl_global_bgp_routing.bgp_router_id
        pfl_isis_routing_process_id = service.pfl_global_isis_routing.isis_routing_process_id
        
        pfs_device_list = service.pfs_list
        for pfs_device in pfs_device_list:
            pfs_bgp_neighbor = pfs_device.pfs_bgp_neighbor_on_leaf
            vars.add ('LOCAL_AS', pfl_bgp_local_as)
            vars.add ('REMOTE_AS', pfs_bgp_neighbor.remote_as)
            vars.add ('NEIGHBOR_IPV4', pfs_bgp_neighbor.neighbor_ipv4)
            vars.add('PEERING_DEVICE', pfl_device_name)
            pfs_bgp_neighbor_on_leaf_template = ncs.template.Template(pfs_bgp_neighbor)
            pfs_bgp_neighbor_on_leaf_template.apply('pfl-to-pfs-bgp-neighbor', vars)
            
            pfl_bgp_neighbor = pfs_device.pfl_bgp_neighbor_on_spine
            vars.add ('LOCAL_AS', pfs_bgp_neighbor.remote_as)
            vars.add ('REMOTE_AS', pfl_bgp_local_as)
            vars.add ('NEIGHBOR_IPV4', pfl_bgp_router_id)
            vars.add('PEERING_DEVICE', pfs_device.pfs_device_name)
            pfl_bgp_neighbor_on_spine_template = ncs.template.Template(pfl_bgp_neighbor)
            pfl_bgp_neighbor_on_spine_template.apply('pfl-to-pfs-bgp-neighbor', vars)
            
            pfs_isis_routing_interface = pfs_device.pfs_interface
            vars.add('ISIS_ROUTING_PROCESS_ID',pfl_isis_routing_process_id)
            pfs_isis_routing_interface_template = ncs.template.Template(pfs_isis_routing_interface)
            pfs_isis_routing_interface_template.apply('pfl-to-pfs-isis-routing-interface', vars)
            
            pfl_isis_routing_interface = pfs_device.pfl_interface
            vars.add('ISIS_ROUTING_PROCESS_ID',pfl_isis_routing_process_id)
            vars.add('PEERING_DEVICE', pfl_device_name)
            pfl_isis_routing_interface_template = ncs.template.Template(pfl_isis_routing_interface)
            pfl_isis_routing_interface_template.apply('pfl-to-pfs-isis-routing-interface', vars)
            
# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        # The application class sets up logging for us. It is accessible
        # through 'self.log' and is a ncs.log.Log instance.
        self.log.info('Main RUNNING')

        # Service callbacks require a registration for a 'service point',
        # as specified in the corresponding data model.
        #
        self.register_service('pfl-to-pfs-routing-servicepoint', ServiceCallbacks)

        # If we registered any callback(s) above, the Application class
        # took care of creating a daemon (related to the service/action point).

        # When this setup method is finished, all registrations are
        # considered done and the application is 'started'.

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.info('Main FINISHED')
