
#    MF-flat-l2vpn

###  1. Introduction:

This package will configure a flat end-to-end l2vpn service by either using Static PW or EVPN-VPWS.

##### Following configurations are supported as part of this service

*   l2vpn static PW
*   l2vpn EVPN-VPWS


### 2. Topology:

##### [Access Router] ——- (EVPN-VPWS or Static PW) ——— [Access Router]

Access Router **:**
NCS5xxx/NCS5xx series router running Cisco's IOS XR software.

Aggregation Router **:**
Cisco ASR9000 series router running IOS XR software.


### 3.	Configuration Example:

* MF-flat-l2vpn p2p service :

```sh

admin@ncs(config)# services MF-flat-l2vpn l2vpn-01 service-type p2p MF-flat-l2vpn-p2p pw-id 100 pw-mtu 1600 local-site local-pe cisco-ios-01 local-int-type GigabitEthernet local-int-id 0/0/1 local-int-description l2vpn-p2p-asr920 intf-encap untagged local-service-inst-id 1001 xconnect-local-ip 12.0.0.0 xconnect-remote-ip 14.0.0.1 mpls-local-label 100 mpls-remote-label 100 pw-class mpls-nso control-word yes tunnel-interface local-tunnel-int-id 0 local-tunnel-source 1 te-metric igp
Value for 'MF-flat-l2vpn-p2p remote-site remote-pe' [cisco-ios-00,cisco-ios-02,cisco-ios-03,cisco-ios-04,...]: cisco-ios-02
Value for 'MF-flat-l2vpn-p2p remote-site remote-int-type' [FortyGigE,GigabitEthernet,HundredGigE,TenGigE]: GigabitEthernet
Value for 'MF-flat-l2vpn-p2p remote-site remote-int-id' (<string>): 0/0/0/9
Value for 'MF-flat-l2vpn-p2p remote-site remote-intf-encap' [dot1q,untagged]: untagged
Value for 'MF-flat-l2vpn-p2p remote-site remote-service-inst-id' (<int>): 1002
Value for 'MF-flat-l2vpn-p2p remote-site remote-pw-class' (<string>): mpls-ncs
Value for 'MF-flat-l2vpn-p2p remote-site tunnel-interface remote-tunnel-int-id' (<string>): 10
Value for 'MF-flat-l2vpn-p2p remote-site tunnel-interface remote-tunnel-source' (<string>): 5
admin@ncs(config-MF-flat-l2vpn-l2vpn-01)# top                                                                
admin@ncs(config)# services MF-flat-l2vpn l2vpn-01 service-type p2p MF-flat-l2vpn-p2p remote-site remote-int-description l2vpn-p2p-asr920
admin@ncs(config-MF-flat-l2vpn-l2vpn-01)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name cisco-ios-01
        data interface Tunnel0
              ip unnumbered Loopback1
              no shutdown
              tunnel source Loopback1
              tunnel destination 14.0.0.1
              tunnel mode mpls traffic-eng
              tunnel mpls traffic-eng path-option 1 dynamic segment-routing pce
              tunnel mpls traffic-eng path-selection metric igp
              tunnel mpls traffic-eng path-selection segment-routing adjacency protected
             exit
             interface GigabitEthernet0/0/1
              description "l2vpn-p2p-asr920"
              no ip address
              no switchport
              negotiation auto
              service instance 1001 ethernet
               encapsulation default
              exit
             exit
             pseudowire-class mpls-nso
              encapsulation mpls
              protocol none
              preferred-path interface Tunnel0
             !
             interface GigabitEthernet0/0/1
              service instance 1001 ethernet
               xconnect 14.0.0.1 100 encapsulation mpls manual pw-class mpls-nso
                mpls label 100 100
                mpls control-word
                !
              exit
              no keepalive
              mtu         1600
              no shutdown
             exit
             pseudowire-static-oam class static-oam
              timeout refresh send 10
             !
    }
    device {
        name cisco-ios-02
        data interface Tunnel10
              ip unnumbered Loopback5
              no shutdown
              tunnel source Loopback5
              tunnel destination 12.0.0.0
              tunnel mode mpls traffic-eng
              tunnel mpls traffic-eng path-option 1 dynamic segment-routing pce
              tunnel mpls traffic-eng path-selection metric igp
              tunnel mpls traffic-eng path-selection segment-routing adjacency protected
             exit
             interface GigabitEthernet0/0/0/9
              description "l2vpn-p2p-asr920"
              no ip address
              no switchport
              negotiation auto
              service instance 1002 ethernet
               encapsulation default
              exit
             exit
             pseudowire-class mpls-ncs
              encapsulation mpls
              protocol none
              preferred-path interface Tunnel10
             !
             interface GigabitEthernet0/0/0/9
              service instance 1002 ethernet
               xconnect 12.0.0.0 100 encapsulation mpls manual pw-class mpls-ncs
                mpls label 100 100
                mpls control-word
                !
              exit
              no keepalive
              mtu         1600
              no shutdown
             exit
             pseudowire-static-oam class static-oam
              timeout refresh send 10
             !
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```

* MF-flat-l2vpn EVPN-VPWS service :

```sh

admin@ncs(config)# services MF-flat-l2vpn l2vpn-evpn-vpws-01 service-type evpn-vpws MF-flat-l2vpn-evpn-vpws evi-id 1001 local-site local-pe iosxr-05 local-int-type FortyGigE local-int-id 0/0/1/0 local-int-description l2vpn-vpws-01 intf-encap untagged xconnect-group-name evpv_vpws_nso p2p-name odn_nso evi-source 4 evi-target 3
Value for 'MF-flat-l2vpn-evpn-vpws remote-site remote-pe' [cisco-ios-00,cisco-ios-01,cisco-ios-02,cisco-ios-03,...]: iosxr-06
Value for 'MF-flat-l2vpn-evpn-vpws remote-site remote-int-type' [FortyGigE,GigabitEthernet,HundredGigE,TenGigE]: FortyGigE
Value for 'MF-flat-l2vpn-evpn-vpws remote-site remote-int-id' (<string>): 0/0/2/1
Value for 'MF-flat-l2vpn-evpn-vpws remote-site remote-intf-encap' [dot1q,untagged]: untagged
Value for 'MF-flat-l2vpn-evpn-vpws remote-site remote-xconnect-group-name' (<string>): evpn_test
Value for 'MF-flat-l2vpn-evpn-vpws remote-site remote-p2p-name' (<string>): odn_test
admin@ncs(config-MF-flat-l2vpn-l2vpn-evpn-vpws-01)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-05
        data interface FortyGigE 0/0/1/0
              description "l2vpn-vpws-01"
              l2transport
              exit
             exit
             l2vpn
              xconnect group evpv_vpws_nso
               p2p odn_nso
                interface FortyGigE0/0/1/0
                neighbor evpn evi 1001 target 4 source 3
                exit
               exit
              exit
             exit
    }
    device {
        name iosxr-06
        data interface FortyGigE 0/0/2/1
              l2transport
              exit
             exit
             l2vpn
              xconnect group evpn_test
               p2p odn_test
                interface FortyGigE0/0/2/1
                neighbor evpn evi 1001 target 3 source 4
                exit
               exit
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-ios     5.9.2](https://earth.tail-f.com:8443/ncs-pkgs/cisco-ios/4.5.5/ncs-4.5.5-cisco-ios-5.9.2.signed.bin)
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

##### Network Device Validated OS version	:
  * XR software version: 6.3.2
  * XE software version: 16.8.1

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [MF-flat-l2vpn p2p Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=a73c947f5f5140ef81fa4edca4506d8d)

  Password : **ZdZAHy9E**

  [MF-flat-L2vpn evpn-vpws Demo](https://cisco.webex.com/ciscosales/lsr.php?RCID=fce71fc154fa4bdf9833e2192f3fa393)

  Password : **aWDJQWi5**


### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
