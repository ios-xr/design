# -*- mode: python; python-indent: 4 -*-
import ncs
from ncs.application import Service


# ---------------------------
# ASPathSet SERVICE CALLBACK 
# ---------------------------
class ASPathSetServiceCallback(Service):

    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.debug('Service create(service=', service._path, ')')

        # Initialize local variables
        template_vars = ncs.template.Variables()
        template = ncs.template.Template(service)
        as_path_set_name = None
        
        # Parse the service inputs
        as_path_set_name_choice = service.as_path_set_choice
        if as_path_set_name_choice == 'user-defined-as-path-set':
            as_path_set_name = service.user_defined_as_path_set
            template_vars.add('AS_PATH_SET_NAME', as_path_set_name)
        elif as_path_set_name_choice == 'predefined-as-path-set':
            #User Chose to deploy Predefined as-path set
            as_path_set_name = service.predefined_as_path_set
            predefined_as_path_set = root.predefined_rpl_configs.as_path_set[as_path_set_name].set
            
            template_vars.add('AS_PATH_SET_NAME', as_path_set_name)
            for set in predefined_as_path_set:
                as_path_set_value = set.value
                template_vars.add('AS_PATH_SET_VALUE', as_path_set_value)
                template.apply('as-path-set-service-template', template_vars)
        
        # Parse user-defined as-path-set match Specifications
        match_specs = service.as_path_set_match_specification
        for match_spec in match_specs:
            as_path_set_match_attr = match_spec.as_path_set_match_attribute
            as_path_set_value = str(as_path_set_match_attr)
            if as_path_set_match_attr == 'originates-from' or as_path_set_match_attr == 'passes-through' or as_path_set_match_attr == 'neighbor-is':
                as_num_list = match_spec.as_number_list
                is_exact = match_spec.is_exact
                if(is_exact):
                    as_path_set_value = as_path_set_value + " '" + as_num_list  + "' exact" 
                else:
                    as_path_set_value = as_path_set_value + " '" + as_num_list  + "'" 
            elif as_path_set_match_attr == 'length' or as_path_set_match_attr == 'unique-length':
                match_num_of_ASNs = str(match_spec.match_num_of_ASNs)
                num_of_ASNs = match_spec.num_of_ASNs
                as_path_set_value = as_path_set_value + " " + match_num_of_ASNs + " " + str(num_of_ASNs) 
            elif as_path_set_match_attr == 'ios-regex' or as_path_set_match_attr == 'dfa-regex':   
                ios_dfa_regex = match_spec.ios_dfa_regex
                as_path_set_value = as_path_set_value + " '" + ios_dfa_regex  + "'"
                
            template_vars.add('AS_PATH_SET_VALUE', as_path_set_value)
            template.apply('as-path-set-service-template', template_vars)
            
# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class ASPathSetService(ncs.application.Application):
    def setup(self):
        self.log.debug('ASPathSetService RUNNING')

        #Register the as-path-set-service-servicepoint with the callback class
        self.register_service('as-path-set-service-servicepoint', ASPathSetServiceCallback)

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.info('ASPathSetService FINISHED')
