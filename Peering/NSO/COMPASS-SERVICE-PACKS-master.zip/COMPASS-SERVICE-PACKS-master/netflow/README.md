
#  netflow

###  1. Introduction:

This package will enable or disable NetFlow, including data export, on IOS-XR devices on a per-interface basis.

##### Following configurations are supported as part of this service

*    Interfaces supported :
   * Bundle-Ether 
   * FortyGigE  
   * GigabitEthernet  
   * HundredGigE  
   * TenGigE


### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# netflow iosxr-01 netflow-server 12.0.0.1 port 8801 interface Bundle-Ether 10
admin@ncs(config-interface-Bundle-Ether/10)# top
admin@ncs(config)# commit dry-run outformat native 
native {
    device {
        name iosxr-01
        data flow exporter-map nf-export
              version v9
               options interface-table timeout 60
               options sampler-table timeout 60
               template timeout 30
              exit
              transport udp 8801
              source Loopback0
              destination 12.0.0.1
             exit
             flow monitor-map flow-monitor-ipv4
              record ipv4
              option   bgpattr
              exporter nf-export
              cache entries 50000
              cache timeout active 60
              cache timeout inactive 10
             exit
             flow monitor-map flow-monitor-ipv6
              record ipv6
              option   bgpattr
              exporter nf-export
              cache timeout active 60
              cache timeout inactive 10
             exit
             flow monitor-map flow-monitor-mpls
              record mpls ipv4-ipv6-fields
              option   bgpattr
              exporter nf-export
              cache timeout active 60
              cache timeout inactive 10
             exit
             sampler-map nf-sample-8192
              random 1 out-of 8192
             exit
             interface Bundle-Ether 10
              flow ipv4 monitor flow-monitor-ipv4 sampler nf-sample-8192 ingress
              flow ipv6 monitor flow-monitor-ipv6 sampler nf-sample-8192 ingress
              flow mpls monitor flow-monitor-mpls sampler nf-sample-8192 ingress
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)# 

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ netflow Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=4ac611e76add4fa8bc489fa8499f5d6a)

  Password : **hPgPWEf2**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
