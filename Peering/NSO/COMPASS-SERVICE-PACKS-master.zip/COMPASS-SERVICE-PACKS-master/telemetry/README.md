
#  telemetry


###  1. Introduction:

This package will enable or disable model-driven Telemetry on IOS-XR devices. 

##### Following configurations are supported as part of this service

Supported Sensor Groups:

1. cisco-bgp-ipv4
2. cisco-bgp-ipv6
3. cisco-bgp-rib
4. cisco-bundle, cisco-isis
5. cisco-lldp
6. cisco-platform 
7. cisco-qos
7. oc-acl
8. oc-bgp
9. oc-bgp-rib
10. oc-bundle
11. oc-mpls
12. oc-platform

Each Sensor Groups have predefined Sensor Path defined in telemetry-template.xml


Supported Source Interafce:

1. HundredGigE;
2. Bundle-Ether;
3. FortyGigE;
4. GigabitEthernet;
5. TenGigE;

	
### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# telemetry iosxr-08 destination-group Destination01 vrf NSO-VRF address-family 10.0.0.1 100 encoding gpb protocol udp
admin@ncs(config-address-family-10.0.0.1/100)# top
admin@ncs(config)# telemetry iosxr-08 sensor-group cisco-bgp-ipv4
admin@ncs(config-sensor-group-cisco-bgp-ipv4)# top
admin@ncs(config)# telemetry iosxr-08 subscription Subscription01 sensor-group-id cisco-bgp-ipv4 interval 20000
admin@ncs(config-sensor-group-id-cisco-bgp-ipv4)# top
admin@ncs(config)# telemetry iosxr-08 subscription Subscription01 destination-id Destination01
admin@ncs(config-destination-id-Destination01)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-08
        data telemetry model-driven
              destination-group Destination01
               vrf NSO-VRF
               address-family ipv4 10.0.0.1 port 100
                encoding gpb
                protocol udp
               exit
              exit
              sensor-group cisco-bgp-ipv4
               sensor-path Cisco-IOS-XR-ipv4-bgp-oper/bgp/instances/instance/instance-active/default-vrf/neighbors
               sensor-path Cisco-IOS-XR-ipv4-bgp-oper:bgp/instances/instance/instance-active/default-vrf/bmp
               sensor-path Cisco-IOS-XR-ipv4-bgp-oper:bgp/instances/instance/instance-active/default-vrf/neighbors/neighbor
               sensor-path Cisco-IOS-XR-ipv4-bgp-oper:bgp/instances/instance/instance-active/default-vrf/process-info/global
               sensor-path Cisco-IOS-XR-ipv4-bgp-oper:bgp/instances/instance/instance-active/default-vrf/process-info/performance-statistics
               sensor-path Cisco-IOS-XR-ipv4-bgp-oper:bgp/instances/instance/instance-active/default-vrf/process-info/vrf
              exit
              subscription Subscription01
               sensor-group-id cisco-bgp-ipv4 sample-interval 20000
               destination-id Destination01
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#


```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ telemetry Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=da30dba1b2fa4f16a05ca0e5ec83b301)

  Password : **BnGqGim5**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
