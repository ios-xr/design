
#  pfs-global-bgp

###  1. Introduction:

This package will configure global BGP routing on a single IOS-XR based Peering Fabric Spine (PFS) node. 


##### Following configurations are supported as part of this service
 * Global BGP Routing configurations  on a single Peering fabric spine node
### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# services pfs-global-bgp iosxr-04 bgp-router 120 bgp-router-id 12.0.1.2 session-group-encrypted-password test
admin@ncs(config-bgp-router-120)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-04
        data router bgp 120
              bgp router-id 12.0.1.2
              bgp bestpath aigp ignore
              bgp bestpath med always
              bgp bestpath as-path multipath-relax
              ibgp policy out enforce-modifications
              address-family ipv4 unicast
               additional-paths receive
               maximum-paths ebgp 32
               maximum-paths ibgp 32
              exit
              address-family ipv6 unicast
               additional-paths receive
               bgp attribute-download
               maximum-paths ebgp 32
               maximum-paths ibgp 32
              exit
              address-family link-state link-state
              exit
              af-group v4-af-pfl address-family ipv4 unicast
               multipath
               soft-reconfiguration inbound always
               next-hop-self
               route-reflector-client
              exit
              af-group v6-af-pfl address-family ipv6 unicast
               multipath
               soft-reconfiguration inbound always
               next-hop-self
               route-reflector-client
              exit
              neighbor-group v4-pfl
               address-family ipv4 unicast
                use af-group v4-af-pfl
               exit
               use session-group pfl-session
              exit
              neighbor-group v6-pfl
               address-family ipv6 unicast
                use af-group v6-af-pfl
               exit
               use session-group pfl-session
              exit
              session-group pfl-session
               password encrypted test
               update-source Loopback0
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#


```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ pfs-global-bgp Demo ]()

  Password : ** **

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
