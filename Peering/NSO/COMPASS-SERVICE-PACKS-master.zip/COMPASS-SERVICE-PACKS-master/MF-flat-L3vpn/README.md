
#    MF-flat-L3vpn

###  1. Introduction:

> Provisioning End to End flat services (MF-flat-L3vpn)

This package will configure a flat end-to-end l3vpn service by either using single or multiple Access Nodes.

##### Following configurations are supported as part of this service

*   vrf (ipv4 and/or ipv6 address-family) on 2 or more  endpoints

*   interface (ipv4 and/or ipv6) on 2 or more  endpoints

*   BGP neighbor (ipv4 and/or ipv6) on 2 or more  endpoints


### 2. Topology:

##### Access Router —— L3vpn —— Access Router

 Access Router **:** ASR920 device running Cisco's IOS XE software  version 16.8.1

### 3.	Configuration Example:

```sh

admin@ncs(config)# services MF-flat-L3vpn L3vpn-01 endpoint cisco-ios-01 if-id 8 end-type port if-type GigabitEthernet vrf vrf-definition L3VPN_NSO_SRODN_1 route-distinguisher 175:175 address-family ipv4 vpn-target 175:1 rt-type both
admin@ncs(config-vpn-target-175:1)# top
admin@ncs(config)# services MF-flat-L3vpn L3vpn-01 endpoint cisco-ios-01 as-no 100 pe-ip-addr 177.0.1.1 end-type port mtu 9216 pe-mask 255.255.255.0 ce-pe-prot e-bgp neighbor-ipv4 177.0.0.1 remote-as-ipv4 100
admin@ncs(config-ce-pe-prot)# top
admin@ncs(config)# services MF-flat-L3vpn L3vpn-01 endpoint cisco-ios-02 if-id 8 end-type port if-type GigabitEthernet vrf vrf-definition L3VPN_NSO_SRODN_1 route-distinguisher 175:175 address-family ipv4 vpn-target 175:1 rt-type both
admin@ncs(config-vpn-target-175:1)# top
admin@ncs(config)# services MF-flat-L3vpn L3vpn-01 endpoint cisco-ios-02 as-no 100 pe-ip-addr 177.0.0.1 end-type port mtu 9216 pe-mask 255.255.255.0 ce-pe-prot e-bgp neighbor-ipv4 177.0.1.1 remote-as-ipv4 100 neighbor-ipv6 2001:dead:b33f:0:1:1:1:1 remote-as-ipv6 100
admin@ncs(config-ce-pe-prot)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name cisco-ios-01
        data vrf definition L3VPN_NSO_SRODN_1
              rd 175:175
              route-target export 175:1
              route-target import 175:1
              address-family ipv4
               exit-address-family
              !
             !
             interface GigabitEthernet8
              no switchport
              negotiation auto
              vrf forwarding L3VPN_NSO_SRODN_1
              ip address 177.0.1.1 255.255.255.0
              mtu 9216
              no shutdown
             exit
             router bgp 100
              address-family ipv4 unicast vrf L3VPN_NSO_SRODN_1
               neighbor 177.0.0.1 remote-as 100
               neighbor 177.0.0.1 activate
               exit-address-family
              !
             !
    }
    device {
        name cisco-ios-02
        data vrf definition L3VPN_NSO_SRODN_1
              rd 175:175
              route-target export 175:1
              route-target import 175:1
              address-family ipv4
               exit-address-family
              !
             !
             interface GigabitEthernet8
              no switchport
              negotiation auto
              vrf forwarding L3VPN_NSO_SRODN_1
              ip address 177.0.0.1 255.255.255.0
              mtu 9216
              no shutdown
             exit
             router bgp 100
              address-family ipv4 unicast vrf L3VPN_NSO_SRODN_1
               neighbor 177.0.1.1 remote-as 100
               neighbor 177.0.1.1 activate
               exit-address-family
              !
             !
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#


```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-ios     5.9.2](https://earth.tail-f.com:8443/ncs-pkgs/cisco-ios/4.5.5/ncs-4.5.5-cisco-ios-5.9.2.signed.bin)
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

##### Network Device Validated OS version	:
  * XR software version: 6.3.2
  * XE software version: 16.8.1

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ MF-flat-L3vpn Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=ac2c0a2587234bf49925f5e79113eb3f)

  Password : **WrQinMj7**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
