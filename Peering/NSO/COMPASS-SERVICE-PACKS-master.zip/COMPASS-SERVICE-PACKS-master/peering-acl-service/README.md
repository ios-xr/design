
#    peering-acl-service

###  1. Introduction:

This package will configure and apply Peer infrastructure IPv4/IPv6 Access Control Lists (ACL), on IOS-XR devices on a per peering interface basis.

Set of IPv4 and IPV6 access rules have been pre-defined in the XML template of this service package, which are applied on respective PFL devices when the service is instantiated.

##### Following configurations are supported as part of this service

*    ACL (IPv4 and IPv6) on single or multiple peering devices.


### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh
admin@ncs(config)# services peering-acl-service peer-acl-01 acl-ip-version ipv4 acl-name EDGE-INGRESS peer-device-names iosxr-00
admin@ncs(config-peering-acl-service-peer-acl-01)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-00
        data ipv4 access-list ACL-NSO
              100 remark BOGON sources
              101 deny ipv4 0.0.0.0/8 any
              102 deny ipv4 10.0.0.0/8 any
              103 deny ipv4 100.64.0.0/10 any
              104 deny ipv4 127.0.0.0/8 any
              105 deny ipv4 169.254.0.0/16 any
              106 deny ipv4 172.16.0.0/12 any
              107 deny ipv4 192.0.0.0/24 any
              108 deny ipv4 192.0.2.0/24 any
              109 deny ipv4 192.168.0.0/16 any
              110 deny ipv4 198.18.0.0/15 any
              111 deny ipv4 198.51.100.0/24 any
              112 deny ipv4 203.0.113.0/24 any
              113 deny ipv4 224.0.0.0/3 any
              200 remark Denied IP Protocols
              202 deny udp any any eq 19
              300 remark Permitted ICMP Types
              301 permit icmp any any echo-reply
              302 permit icmp any any echo
              303 permit icmp any any ttl-exceeded
              304 permit icmp any any unreachable
              305 permit icmp any any packet-too-big
              306 deny icmp any any
              1000 remark Default permit
              1001 permit ipv4 any any
             exit
    }
}
admin@ncs(config)# commit

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ peering-acl-service Demo ]()

  Password : ** **

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
