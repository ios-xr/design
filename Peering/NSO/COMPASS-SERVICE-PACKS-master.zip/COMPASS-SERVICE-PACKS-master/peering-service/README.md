
#    peering-service

###  1. Introduction:

This package will configure Peering Fabric Leaf (PFL) node interfaces and associated BGP variables on IOS-XR based nodes to establish BGP sessions with BGP peers.

Service configuration is done for each peer node and associated pfl node/s.
##### Following configurations are supported as part of this service

*   Peer interface (ipv4 and/or ipv6) on single or multiple PFL Nodes
*   Peer BGP neighbor/s (ipv4 and/or ipv6) on single or multiple PFL Nodes


### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```

### 3.	Configuration Example:

```sh

admin@ncs(config)# services peering-service iosxr-01 pfl-list iosxr-09 as-path ignore disable-fast-external-fallover peer-interface-type Bundle-Ether peer-interface-id 1 int-description Peering-interface int-ipv4-address 12.0.0.1/32 ipv4-in-access-group acl-in ipv4-out-access-group acl-out member-interface bundle-mode active bundle-member 0/0/0/4 member-description Bundle-1-member
Value for 'member-interface member-interface-type' [FortyGigE,HundredGigE,TenGigE]: HundredGigE
admin@ncs(config-bundle-member-0/0/0/4)# top
admin@ncs(config)# services peering-service iosxr-01 pfl-list iosxr-09 local-as 100 service-policy qos vlan-id 15 peer-bgp-neighbor in-route-policy peer-in out-route-policy peer-out max-prefix-limit 1000 neighbor-ipv4 12.0.0.1 bgp-ipv4-description ext-peer-v4 neighbor-ipv6 2001:dead:b33f:0:1:1:1:3 bgp-ipv6-description ext-peer-v6 remote-as 220 session-group peer-session af-ipv4-group af-v4-peer af-ipv6-group af-v6-peer neighbor-group peer-grp discard-extra-paths threshold 80
admin@ncs(config-pfl-list-iosxr-09)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-09
        data interface Bundle-Ether 1
              description "Peering-interface"
              service-policy input qos
              ipv4 address 12.0.0.1 /32
              ipv4 access-group acl-out egress
              ipv4 access-group acl-in ingress
              lldp
               transmit disable
              exit
             exit
             interface HundredGigE 0/0/0/4
              description "Bundle-1-member"
              bundle id 1 mode active
             exit
             router bgp 100
              bgp bestpath as-path ignore
              bgp fast-external-fallover disable
              neighbor 12.0.0.1
               remote-as   220
               enforce-first-as
               description "ext-peer-v4"
               ttl-security inheritance-disable
               address-family ipv4 unicast
                route-policy peer-in in
                route-policy peer-out out
                maximum-prefix 1000 80 discard-extra-paths
                use af-group af-v4-peer
               exit
               use neighbor-group peer-grp
               use session-group peer-session
              exit
              neighbor 2001:dead:b33f:0:1:1:1:3
               remote-as   220
               enforce-first-as
               description "ext-peer-v6"
               ttl-security inheritance-disable
               address-family ipv6 unicast
                route-policy peer-in in
                route-policy peer-out out
                maximum-prefix 1000 80 discard-extra-paths
                use af-group af-v6-peer
               exit
               use neighbor-group peer-grp
               use session-group peer-session
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-ios     5.9.2](https://earth.tail-f.com:8443/ncs-pkgs/cisco-ios/4.5.5/ncs-4.5.5-cisco-ios-5.9.2.signed.bin)
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ peering-service Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=9280cd5463274e50ad583f5da5ffeb74)

  Password : **yVJgft6W**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
