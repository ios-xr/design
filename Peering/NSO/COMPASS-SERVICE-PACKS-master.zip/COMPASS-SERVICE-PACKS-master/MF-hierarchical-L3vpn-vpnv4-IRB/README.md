
#    MF-hierarchical-L3vpn-vpnv4-IRB

###  1. Introduction:

This package will configure a Hierarchal L3vpn service with anycast redundancy.

As part of the service, anycast static PW will be configured between Access and Aggregation and L3 VPN service will be enabled between local and remote Aggregation routers.



##### Following configurations are supported as part of this service

*   l2vpn,interface ( Access PE XR device)
*   interface ( Access PE XE device)
*   interface,l2vpn,evpn,vrf,router-vrf (on Aggregation PE device & Redundant aggregation PE device)



### 2. Topology:

##### [Access Router] ——-  (static anycast PW) ——— (IRB) [Agg1 & Agg2]———— (L3vpn) ——- [Remote Agg/access network]

Access Router **:**
NCS5xxx/NCS5xx series router running Cisco's IOS XR software.

Aggregation Router **:**
Cisco ASR9000 series router running IOS XR software.


### 3.	Configuration Example:

```sh

admin@ncs(config)# services MF-hierarchical-L3vpn-vpnv4-IRB l3vpn-IRB-01 control-word yes pw-id 5001 aggregation-pe-site aggregation-pe iosxr-02 redundant-aggregation-pe iosxr-03 bridge-domain VRF1 bridge-group Static-VPWS-H-L3VPN-IRB esi-value 12.00.00.00.00.00.50.00.01 evi-id 12001 int-id 1 ip-addr 12.0.1.3 ip-mask 255.255.255.0 ipv6-addr 2020:2020:25:33:22::33/128 mac-address 12.0.2 mpls-local-label 3003 mpls-remote-label 4003 neighbor-ip 100.0.1.50 pw-class static-pw-h-l3vpn-class vrf L3VPN-AnyCast-ODNTE-VRF1 route-target 100:10001 rt-type both
Value for 'aggregation-pe-site local-as' (<unsignedShort>): 100
Value for 'access-pe-site access-pe' [cisco-ios-00,cisco-ios-01,cisco-ios-02,cisco-ios-03,...]: iosxr-05
Value for 'access-pe-site xr-int-type' [FortyGigE,GigabitEthernet,HundredGigE,TenGigE]: HundredGigE
Value for 'access-pe-site int-id' (<string>): 0/0/1/3
Value for 'access-pe-site intf-encap' [dot1q,untagged]: dot1q
Value for 'access-pe-site vlan-id' (<int, 1 .. 4000>): 10
Value for 'access-pe-site sub-intf-id' (<int>): 100
Value for 'access-pe-site pw-class' (<string>): l3vpn-static-pw-nso
Value for 'access-pe-site ip-addr' (<IPv4 address>): 100.100.0.13
Value for 'access-pe-site xconnect-group' (<string>): Static-L3vpn-NSO
Value for 'access-pe-site p2p-name' (<string>): L3vpn-P2P-NSO
admin@ncs(config-route-target-100:10001)# top
admin@ncs(config)# services MF-hierarchical-L3vpn-vpnv4-IRB l3vpn-IRB-01 aggregation-pe-site bgp-parameters neighbor-ipv4 13.0.0.0 neighbor-ipv6 2001:dead:b33f:0:1:1:1:1 remote-as 12 redistribute-connected route-distinguisher auto
admin@ncs(config-MF-hierarchical-L3vpn-vpnv4-IRB-l3vpn-IRB-01)# top             
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-02
        data vrf L3VPN-AnyCast-ODNTE-VRF1
              address-family ipv4 unicast
               import route-target
                100:10001
               exit
               export route-target
                100:10001
               exit
              exit
              address-family ipv6 unicast
               import route-target
                100:10001
               exit
               export route-target
                100:10001
               exit
              exit
             exit
             interface BVI 1
              host-routing
              vrf          L3VPN-AnyCast-ODNTE-VRF1
              ipv4 address 12.0.1.3 255.255.255.0
              ipv6 address 2020:2020:25:33:22::33/128
              mac-address  12.0.2
             exit
             evpn
              evi 12001
               advertise-mac
               exit
              exit
              virtual neighbor 100.0.1.50 pw-id 5001
               ethernet-segment
                identifier type 0 12.00.00.00.00.00.50.00.01
               exit
              exit
             exit
             l2vpn
              pw-class static-pw-h-l3vpn-class
               encapsulation mpls
                control-word
               exit
              exit
              bridge group Static-VPWS-H-L3VPN-IRB
               bridge-domain VRF1
                neighbor 100.0.1.50 pw-id 5001
                 pw-class static-pw-h-l3vpn-class
                 mpls static label local 3003 remote 4003
                exit
                routed interface BVI1
                 split-horizon group core
                 !
                evi 12001
                exit
               exit
              exit
             exit
             router bgp 100
              vrf L3VPN-AnyCast-ODNTE-VRF1
               rd auto
               address-family ipv4 unicast
                redistribute connected
               exit
               address-family ipv6 unicast
                redistribute connected
               exit
               neighbor 13.0.0.0
                remote-as 12
               exit
               neighbor 2001:dead:b33f:0:1:1:1:1
                remote-as 12
               exit
              exit
             exit
    }
    device {
        name iosxr-03
        data vrf L3VPN-AnyCast-ODNTE-VRF1
              address-family ipv4 unicast
               import route-target
                100:10001
               exit
               export route-target
                100:10001
               exit
              exit
              address-family ipv6 unicast
               import route-target
                100:10001
               exit
               export route-target
                100:10001
               exit
              exit
             exit
             interface BVI 1
              host-routing
              vrf          L3VPN-AnyCast-ODNTE-VRF1
              ipv4 address 12.0.1.3 255.255.255.0
              ipv6 address 2020:2020:25:33:22::33/128
              mac-address  12.0.2
             exit
             evpn
              evi 12001
               advertise-mac
               exit
              exit
              virtual neighbor 100.0.1.50 pw-id 5001
               ethernet-segment
                identifier type 0 12.00.00.00.00.00.50.00.01
               exit
              exit
             exit
             l2vpn
              pw-class static-pw-h-l3vpn-class
               encapsulation mpls
                control-word
               exit
              exit
              bridge group Static-VPWS-H-L3VPN-IRB
               bridge-domain VRF1
                neighbor 100.0.1.50 pw-id 5001
                 pw-class static-pw-h-l3vpn-class
                 mpls static label local 3003 remote 4003
                exit
                routed interface BVI1
                 split-horizon group core
                 !
                evi 12001
                exit
               exit
              exit
             exit
             router bgp 100
              vrf L3VPN-AnyCast-ODNTE-VRF1
               rd auto
               address-family ipv4 unicast
                redistribute connected
               exit
               address-family ipv6 unicast
                redistribute connected
               exit
               neighbor 13.0.0.0
                remote-as 12
               exit
               neighbor 2001:dead:b33f:0:1:1:1:1
                remote-as 12
               exit
              exit
             exit
    }
    device {
        name iosxr-05
        data interface HundredGigE 0/0/1/3.100 l2transport
              encapsulation dot1q 10
              rewrite ingress tag pop 1 symmetric
             exit
             l2vpn
              pw-class l3vpn-static-pw-nso
               encapsulation mpls
                control-word
               exit
              exit
              xconnect group Static-L3vpn-NSO
               p2p L3vpn-P2P-NSO
                interface HundredGigE0/0/1/3.100
                neighbor ipv4 100.100.0.13 pw-id 5001
                 mpls static label local 4003 remote 3003
                 pw-class l3vpn-static-pw-nso
                exit
               exit
              exit
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-ios     5.9.2](https://earth.tail-f.com:8443/ncs-pkgs/cisco-ios/4.5.5/ncs-4.5.5-cisco-ios-5.9.2.signed.bin)
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

##### Network Device Validated OS version	:
  * XR software version: 6.3.2
  * XE software version: 16.8.1

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [MF-hierarchical-L3vpn-vpnv4-IRB Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=bcf6669411114eabb7307ace33232423)

  Password : **BnwJ7Fny**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
