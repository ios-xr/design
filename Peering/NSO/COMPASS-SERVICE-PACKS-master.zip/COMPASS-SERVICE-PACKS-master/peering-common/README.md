
#    peering-common

###  1. Introduction:

This package will configure common static variables such as as-path-sets, prefix-sets, and route-policies to be later applied to IOS-XR based BGP peering configurations.
peering-common is a utility package, which contains the yang model and xml template for static as-path-sets, prefix-sets and route-policies.

##### Following configurations are supported as part of this service

*    This package defines the structure to load pre-defined/static as-path sets, prefix sets and route policies.


### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 4.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)


### 5.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
