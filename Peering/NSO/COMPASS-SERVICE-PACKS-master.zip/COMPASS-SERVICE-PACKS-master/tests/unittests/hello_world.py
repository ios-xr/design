def hello():
    print("Hello World!")


class HelloWorld(object):
    def hi(self):
        print("Hi!")
