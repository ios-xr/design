
#    drain-service

###  1. Introduction:

This package will enable or disable the “Drain” policy on IOS-XR based nodes to signal to other routers in the domain to avoid this router for transit traffic and use alternate peers if available. The policy accomplishes this by setting the overload-bit within IS-IS and advertising its Link State Packets (LSP) with the overload-bit set. Once the overload-bit is cleared and advertised throughout the domain, routers within the domain are once again free to use this router for transit. Typical use cases include scheduled maintenance of the router or upstream paths, limited network resources, or some other reason to avoid transit through this peer.

##### Following configurations are supported as part of this service

*   Enable or Disable drain-policy on peer devices

### 2. Topology:

```
pfl1---- pfs1
    \  /     \  
     \/       \p1---pe1
     /\       /
    /  \     /  
pfl2 --- pfs2    
```


### 3.	Configuration Example:

```sh

admin@ncs(config)# services drain-service iosxr-02 isis-name pf-core drain-policy enable
admin@ncs(config-drain-service-iosxr-02)# top
admin@ncs(config)# commit dry-run outformat native
native {
    device {
        name iosxr-02
        data route-policy maintenance
               "  # normal 0, maintenance 1\r\r\n  var globalVar1 1\r\r\n"
              end-policy
             !
             router isis pf-core
              set-overload-bit
              is-type          level-1-2
             exit
    }
}
admin@ncs(config)# commit
Commit complete.
admin@ncs(config)#

```


### 4.	Pre Requisites and Dependencies:

The package has been developed with [NSO 4.5.5]() release and might need to be recompiled for subsequent releases and any XML template dependencies can be resolved.
##### NED Versions Required :
  * [cisco-iosxr   7.0.4](https://earth.tail-f.com:8443/ncs-pkgs/cisco-iosxr/4.5.5/ncs-4.5.5-cisco-iosxr-7.0.4.signed.bin)

### 5.	Package Installation:
  1. Download packages from Artifactory / Github.
  2. Place the downloaded packages in packages directory located in nso run directory.
  3. Make and Reload the packages.(` Service Package has been tested with NCS-4.5.5`)

### 6.	Demo Recording:

  [ drain-service Demo ](https://cisco.webex.com/ciscosales/lsr.php?RCID=15c23be6ba4249b98bc7caa4361b475c)

  Password : **Jjdbn3Pt**

### 7.	Contact Email:

 For any queries & feedback, please contact the following mailer alias: as-nso-service-packs@cisco.com
